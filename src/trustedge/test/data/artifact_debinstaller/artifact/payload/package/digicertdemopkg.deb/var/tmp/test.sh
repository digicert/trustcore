#!/bin/bash
echo "Digicert Demo Application"
