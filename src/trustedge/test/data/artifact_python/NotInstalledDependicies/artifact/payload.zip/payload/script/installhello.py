#!/bin/python3

import sys
print ('Install argument list', sys.argv)
name = sys.argv[1];
print ("Install: Hello {}.".format(name));
