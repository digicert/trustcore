#!/bin/python3

import sys
print ('Rollback argument list', sys.argv)
name = sys.argv[1];
print ("RollbacK: Hello {}.".format(name));
