#!/bin/bash

# Initialize counter
counter=0

# Set the maximum number of iterations
max_iterations=70

# Loop with a counter
while [ $counter -lt $max_iterations ]
do
  # Your commands go here
  echo "Iteration $counter"

  # Sleep for 5 seconds
  sleep 5

  # Increment the counter
  counter=$((counter + 1))
done

echo "Loop has completed $max_iterations iterations."

